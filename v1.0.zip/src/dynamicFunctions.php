<?php

class dynamicFunctions {
    // These functions are used dynamically while a survey is running

    /**
     * Hides the question on the client by setting the HTML options to hidden.
     */
    public static function hideQuestion($event) {
        $event->set("aHtmlOptions", array("hidden" => 1));
    }

    /**
     * Replaces the question text.
     */
    public static function replaceQuestionText($event, $replaceText) {
        $event->set("text", $replaceText);
    }

    /**
     * Appends a script tag to the question text to handle subquestion logic.
     * This script handles setting the text of subquestions based on the LLM response.
     */
    public static function replaceSubquestionText($event) {
        $jsFilePath = "../plugins/LLMSurvey/subQuestionLogic.js";
        // append the script tag to the question html
        $currentText = $event->get("text");
        $scriptTag = "<script src='{$jsFilePath}'></script>";
        $event->set("text", $currentText . $scriptTag);
    }

    /**
     * Returns the table column name for a given question ID.
     * The table is created when the survey is activated.
     * This is used to insert the llm output in the answer fields in the response table when the survey is complete.
     */
    static function getTableColumnById($surveyId, $qid) {
        $availableColumns = SurveyDynamic::model($surveyId)->getAttributes();

        // find key where the ID is correct
        foreach ($availableColumns as $key => $_value) {
            // get the number after the second 'X' and compare it to our id
            if (preg_match('/X(\d+)$/', $key, $matches) && $matches[1] == $qid) {
                return $key;
            }
        }
        return null;
    }

    /**
     * Inserts an answer to a question into the database.
     */
    public static function insertAnswerIntoDB($plugin, $surveyId, $responseId, $questionId, $answer) {
        $column = self::getTableColumnById($surveyId, $questionId);
        if (!isset($column)) {
            $plugin->log("Could not insert answer into db - this questions db field was not found. ($surveyId, $questionId)");
            return;
        }

        Yii::app()->db->createCommand()->update("lime_survey_$surveyId", array($column => $answer), "id=:id", array(":id" => $responseId));
    }
}
