<?php

class functions {
    // These are general functions and functions used to alter the survey or questions when the survey is not active.

    /**
     * Inserts a new hidden question into the survey.
     * Returns if the insertion was successful.
     */
    public static function insertQuestion($surveyId, $groupId, $type = "T", $pos = -1, $title, $text, $language): bool {
        $newQuestion = new Question();
        $newQuestion->sid = $surveyId;
        $newQuestion->gid = $groupId;
        $newQuestion->type = $type;
        $newQuestion->title = $title;
        $newQuestion->question_order = $pos == -1 ? $newQuestion->getHighestQuestionOrderNumberInGroup($groupId) + 1 : $pos;
        $newQuestion->mandatory = "N";
        $newQuestion->other = "N";
        $newQuestion->relevance = "1";

        if ($newQuestion->save()) {
            $newQLang = new QuestionL10n();
            $newQLang->qid = $newQuestion->qid;
            $newQLang->language = $language;
            $newQLang->question = $text;
            $newQLang->help = "This question was automatically inserted by the plugin LLMSurvey. It is hidden from the user and used to store information regarding the LLM request. As long as the plugin is active, the question will reappear every time you activate the survey.";
            $newQLang->save();

            $newQAttr = new QuestionAttribute();
            $newQAttr->qid = $newQuestion->qid;
            $newQAttr->attribute = "hidden";
            $newQAttr->value = "1";
            $newQAttr->save();

            LimeExpressionManager::SetDirtyFlag();
            return true;
        } else {
            return false;
        }
    }

    /**
     * Checks if the question contains a placeholder code.
     */
    public static function isPlaceholderQuestion(Question $question): bool {
        if (preg_match("/^llm\d+$/", $question->title)) {
            return true;
        }
        foreach ($question->subquestions as $sq) {
            if (preg_match("/^llm\d+$/", $sq->title)) {
                return true;
            }
        }
        foreach ($question->answers as $ans) {
            if (preg_match("/^llm\d+$/", $ans->code)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks the question and iterates over its subquestions and answers to find all placeholder codes.
     * Returns an array of all found placeholder numbers. 
     */
    public static function getPlaceholdersOfQuestion(Question $question): array {
        $out = array();
        $code = explode("_", $question->title);
        if (preg_match("/^llm(\d+)$/", $code[0], $matches)) {
            array_push($out, $matches[1]);
        }
        // subquestions
        foreach ($question->subquestions as $sq) {
            if (preg_match("/^llm(\d+)$/", $sq->title, $matches)) {
                array_push($out, $matches[1]);
            }
        }
        // answers
        foreach ($question->answers as $ans) {
            if (preg_match("/^llm(\d+)$/", $ans->code, $matches)) {
                array_push($out, $matches[1]);
            }
        }

        return $out;
    }

    /**
     * Sets the question to non-mandatory. Only works for an inactive survey.
     */
    public static function setNonMandatory(Question $question) {
        // check if subqestion and if so: set parent non mandatory
        if (isset($question->parent)) {
            $question->parent->mandatory = "N";
            $question->parent->save();
        } else {
            $question->mandatory = "N";
            $question->save();
        }
    }

    /**
     * Updates the question order of a question.
     */
    public static function updateQuestionOrder($plugin, Question $question, int $newQuestionOrder) {
        if (isset($question->parent)) {
            $plugin->log("Trying to update the order of a subquestion - can't change the order of subquestions.");
            return;
        }
        $question->question_order = $newQuestionOrder;
        $question->save();
    }
}
