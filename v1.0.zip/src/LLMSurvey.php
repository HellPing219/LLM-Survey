<?php

require_once "llmWrapper.php";
require_once "functions.php";
require_once "dynamicFunctions.php";

class LLMSurvey extends PluginBase {
    protected $storage = "DbStorage";
    static protected $description = "This plugin allows personalized text to be dynamically generated from a language model (LLM) based on participant input and to be rated directly afterwards within the survey.";
    static protected $name = "LLMSurvey";

    protected $settings = array(
        "openRouterKey" => array(
            "type" => "password",
            "label" => "Open Router API Key",
            "default" => "",
        ),
        "llms" => array(
            "type" => "text",
            "label" => "Large Language Models",
            "default" => "",
            "help" => "List the openrouter codes of the models to use here. The codes can be found on <a href='https://openrouter.ai/models' target='_blank'>OpenRouter.ai</a> and they look like this: 'google/gemini-2.5-flash'. Use one line for every entry. You can select a model from this list in each survey settings.",
        )
    );

    public function init() {
        // fired before the advanced settings page is displayed
        $this->subscribe("beforeSurveySettings");

        // fired when the survey settings are saved
        $this->subscribe("newSurveySettings", "saveSurveySettings");

        // fired just before the survey is activated
        $this->subscribe("beforeSurveyActivate");

        // fired before each survey page loads
        $this->subscribe("beforeSurveyPage");

        // fired before the question is rendered
        $this->subscribe("beforeQuestionRender", "replaceQuestionData");

        $this->subscribe("afterSurveyComplete");

        $this->subscribe("afterSurveyDeactivate");

        $this->subscribe("beforeSurveyDelete");

        $this->subscribe("beforeDeactivate");
    }

    /**
     * Sets the survey settings for the plugin in the survey settings page.
     * This method is called before the survey settings are displayed.
     */
    public function beforeSurveySettings() {
        $oEvent = $this->event;
        $llmOptions = explode("\r\n", $this->get("llms", null, null));
        $oEvent->set("surveysettings.{$this->id}", array(
            "name" => get_class($this),
            "settings" => array(
                "helpText" => array(
                    "type" => "info",
                    "label" => "Info",
                    "help" => "These are the plugin settings for this survey. Please activate the survey AFTER you've activated the plugin in the setting below. The survey can be deactivated and activated again. You can find the <a href='https://github.com/HellPing219/LLM-Survey' target='_blank'>full documentation here</a>."
                ),
                "bUse" => array(
                    "type" => "boolean",
                    "label" => "Activate Plugin",
                    "help" => "Mit der Nutzung des Umfragetools bestätige ich, dass ich keine personenbezogenen Daten (vgl. DSGVO Art. 4 Nr. 1) unbefugt oder ohne Aufklärung der Umfrageteilnehmer an Modellbetreiber weitergebe.",
                    "current" => $this->get("bUse", "Survey", $oEvent->get("survey"), "0")
                ),
                "llmodel" => array(
                    "type" => "select",
                    "options" => $llmOptions,
                    "label" => "Large Language Model",
                    "help" => "The language model to use in this survey.",
                    "current" => array_search($this->get("llmodel", "Survey", $oEvent->get("survey")), $llmOptions),
                ),
                "promptInput" => array(
                    "type" => "text",
                    "label" => "Prompt",
                    "help" => "Insert the prompt. You can use \"[questionCode]\" in your prompt to insert answers from questions (or [parentQCode_subQCode] for subquestions).<br/>Give the LLM the instruction to return something. The returned data will have the format [llm1: \"Item1\", llm2: \"Item2\", ...]. Use llm1, llm2, ... in a questionCode to insert the returned LLM output there.<br/>If you asked the LLM to return only one thing, you can simply access it using llm1.<br/><br/><br/><br/>",
                    "current" => $this->get("promptInput", "Survey", $oEvent->get("survey"))
                ),
                "advancedSettings" => array(
                    "type" => "info",
                    "label" => "Advanced Settings",
                    "help" => "Below are the advanced settings. Please proceed with caution and if you know what you are doing. The LLM parameters can be left empty to use the default values for your selected language model."
                ),
                "temperature" => array(
                    "type" => "string",
                    "label" => "Temperature (0-2)",
                    "help" => "OPTIONAL: This setting influences the variety in the model's responses. Lower values lead to more predictable and typical responses, while higher values encourage more diverse and less common responses. At 0, the model always gives the same response for a given input.",
                    "current" => $this->get("temperature", "Survey", $oEvent->get("survey"))
                ),
                "maxTokens" => array(
                    "type" => "int",
                    "label" => "Max Tokens",
                    "help" => "OPTIONAL: This sets the upper limit for the number of tokens the model can generate in response. It won't produce more than this limit. The maximum value is the context length minus the prompt length.",
                    "current" => $this->get("maxTokens", "Survey", $oEvent->get("survey"))
                ),
                "topP" => array(
                    "type" => "string",
                    "label" => "Top P (0-1)",
                    "help" => "OPTIONAL: This setting limits the model's choices to a percentage of likely tokens: only the top tokens whose probabilities add up to P. A lower value makes the model's responses more predictable, while the default setting allows for a full range of token choices. Think of it like a dynamic Top-K.",
                    "current" => $this->get("topP", "Survey", $oEvent->get("survey"))
                ),
                "systemPromptInput" => array(
                    "type" => "text",
                    "label" => "System Prompt",
                    "help" => "Insert the system prompt. Changing this setting can break the plugin and in extension this survey so please proceed with caution. The plugin needs an array of strings back from the LLM in order to map the outputs to the question elements.",
                    "current" => $this->get("systemPromptInput", "Survey", $oEvent->get("survey"), llmWrapper::$defaultSystemPrompt)
                )
            )
        ));
    }

    /**
     * Saves the survey settings for the current survey.
     * This method is called when the survey settings are saved.
     */
    public function saveSurveySettings() {
        $event = $this->event;
        foreach ($event->get("settings") as $name => $value) {
            // special case for selecting the llm in survey settings
            // we want to save the string in the database and not the key (number)
            if ($name == "llmodel") {
                $models = explode("\r\n", $this->get("llms", null, null));
                $this->set($name, $models[$value], "Survey", $event->get("survey"));
                continue;
            }
            // setting name, setting value, string, survey id
            $this->set($name, $value, "Survey", $event->get("survey"));
        }
    }

    /**
     * Performs checks if the settings are in the correct values for the plugin to work.
     */
    function performChecks($event, $surveyId): bool {
        // check if openRouterKey is set
        $openRouterKey = $this->get("openRouterKey", null, null);
        if (empty($openRouterKey)) {
            $event->set("success", false);
            $event->set("message", "Please set an API key in the global settings for the plugin LLMSurvey.");
            return false;
        }

        // check if model is set
        $llmModel = $this->get("llmodel", "Survey", $surveyId);
        if (empty($llmModel)) {
            $event->set("success", false);
            $event->set("message", "Please set the LLM Model in the survey settings.");
            return false;
        }

        // check if prompt is set
        $promptInput = $this->get("promptInput", "Survey", $surveyId);
        if (empty($promptInput)) {
            $event->set("success", false);
            $event->set("message", "Please set the prompt in the survey settings.");
            return false;
        }

        $temperature = $this->get("temperature", "Survey", $surveyId);
        if (!empty($temperature)) {
            if (!is_numeric($temperature) || $temperature < 0 || $temperature > 2) {
                $event->set("success", false);
                $event->set("message", "Please enter a number between 0 and 2 (or nothing) as the temperature setting.");
                return false;
            }
        }

        $maxTokens = $this->get("maxTokens", "Survey", $surveyId);
        if (!empty($maxTokens)) {
            if ($maxTokens <= 0) {
                $event->set("success", false);
                $event->set("message", "Please enter a value above 0 (or nothing) for max tokens setting.");
                return false;
            }
        }

        $topP = $this->get("topP", "Survey", $surveyId);
        if (!empty($topP)) {
            if (!is_numeric($topP) || $topP < 0 || $topP > 1) {
                $event->set("success", false);
                $event->set("message", "Please enter a number between 0 and 1 (or nothing) as the top p setting.");
                return false;
            }
        }

        return true;
    }

    /**
     * Automatically adds hidden questions to save the LLM-output.
     * Adds a hidden question for each placeholder question in the survey to the group of the placeholder questions.
     */
    public function beforeSurveyActivate() {
        $event = $this->event;
        $surveyId = $event->get("surveyId");

        $active = $this->get("bUse", "Survey", $surveyId, false);
        if (!$active) {
            // Plugin is not active for this survey. Skipping checks
            return;
        }

        $checksOK = self::performChecks($event, $surveyId);
        if (!$checksOK) {
            return;
        }

        $survey = Survey::model()->findByPk($surveyId);
        if (!$survey) {
            $event->set("success", false);
            $event->set("message", "Internal error: Could not get the survey object.");
            return;
        }

        // get all parent questions
        $allQuestions = array_values(array_filter($survey->getAllQuestions(), function ($q) {
            return !isset($q->parent);
        }));
        // sort questions by question_order
        usort($allQuestions, function ($item1, $item2) {
            $group1 = QuestionGroup::model()->findByPk($item1->gid);
            $group2 = QuestionGroup::model()->findByPk($item2->gid);
            if ($group1->gid != $group2->gid) {
                return $group1->group_order > $group2->group_order;
            }
            return $item1->question_order > $item2->question_order;
        });

        $currentGid = $allQuestions[0]->gid;
        $currentOrder = 0;
        for ($i = 0; $i < count($allQuestions); $i++) {
            if ($currentGid != $allQuestions[$i]->gid) {
                // we are in a new group
                $currentGid = $allQuestions[$i]->gid;
                $currentOrder = 1;
            } else {
                $currentOrder++;
            }

            if (!functions::isPlaceholderQuestion($allQuestions[$i])) {
                functions::updateQuestionOrder($this, $allQuestions[$i], $currentOrder);
                continue;
            }

            // the current question is or contains placeholder
            functions::setNonMandatory($allQuestions[$i]);

            $placeholderIndexes = functions::getPlaceholdersOfQuestion($allQuestions[$i]);
            for ($j = 0; $j < count($placeholderIndexes); $j++) {
                $success = functions::insertQuestion(
                    $surveyId,
                    $currentGid,
                    "T",
                    $currentOrder,
                    "llmOutput" . $placeholderIndexes[$j],
                    "LLM Output " . $placeholderIndexes[$j],
                    $survey->language
                );
                if ($success) {
                    $currentOrder++;
                }
            }
            // finally update order of placeholder question
            functions::updateQuestionOrder($this, $allQuestions[$i], $currentOrder);
        }
        functions::insertQuestion($surveyId, $currentGid, "T", -1, "languageModel", "Language Model", $survey->language);
        functions::insertQuestion($surveyId, $currentGid, "T", -1, "systemPrompt", "System Prompt", $survey->language);
        functions::insertQuestion($surveyId, $currentGid, "T", -1, "prompt", "Prompt", $survey->language);
        functions::insertQuestion($surveyId, $currentGid, "T", -1, "llmTemperature", "LLM Temperature", $survey->language);
        functions::insertQuestion($surveyId, $currentGid, "T", -1, "llmMaxTokens", "LLM Max Tokens", $survey->language);
        functions::insertQuestion($surveyId, $currentGid, "T", -1, "llmTopP", "LLM Top P", $survey->language);
    }

    /**
     * This function is called when the user changes the survey page.
     * It checks if llm output was generated and if so saves the dynamically generated data.
     */
    public function beforeSurveyPage() {
        $event = $this->event;
        $surveyId = $event->get("surveyId");

        // check if plugin is active
        $active = $this->get("bUse", "Survey", $surveyId, false);
        if (!$active) {
            return;
        }

        //todo: inject js file once

        // get response id through session
        $responseId = Yii::app()->session["survey_$surveyId"]["srid"];
        if (!isset($responseId)) {
            return;
        }

        // check if llm output was generated
        if (empty($this->get("llmoutput", "Response_$surveyId", $responseId))) {
            return;
        }

        self::saveCurrentSurveyState($surveyId, $responseId);
    }

    /**
     * Delete responses from plugin settings for this survey.
     */
    public function afterSurveyDeactivate() {
        $event = $this->event;
        $surveyId = $event->get("surveyId");

        $sql = "DELETE FROM lime_plugin_settings WHERE model = 'Response_$surveyId'";
        Yii::app()->db->createCommand($sql)->execute();
    }

    /**
     * Replaces the question text of the placeholder question with a predefined text.
     */
    public function replaceQuestionData() {
        $event = $this->event;
        $surveyId = $event->get("surveyId");
        $qid = $event->get("qid");

        // check if plugin is active
        $active = $this->get("bUse", "Survey", $surveyId, false);
        if (!$active) {
            return;
        }

        // check if placeholder code is in question or subquestions of this question
        $question = Question::model()->findByPk($qid);
        $subquestionIsPlaceholder = false;
        foreach ($question->subquestions as $sq) {
            if (preg_match("/^llm\d+$/", $sq->title)) {
                $subquestionIsPlaceholder = true;
                break;
            }
        }
        foreach ($question->answers as $ans) {
            if (preg_match("/^llm\d+$/", $ans->code)) {
                $subquestionIsPlaceholder = true;
                break;
            }
        }
        // dont call llm functions if parent is not placeholder AND no child is placeholder
        if (!preg_match("/^llm\d+$/", $event->get("code")) && !$subquestionIsPlaceholder) {
            return;
        }

        // get response id through session
        $responseId = Yii::app()->session["survey_$surveyId"]["srid"];

        // check if we already have a saved LLM-output for this response
        $savedLLMOutput = $this->get("llmoutput", "Response_$surveyId", $responseId);

        $llmOutput = null;
        if (empty($savedLLMOutput)) {
            // if not, we need to call the LLM-API
            $response = $this->pluginManager->getAPI()->getResponse($surveyId, $responseId);
            $prompt = llmWrapper::createPrompt($surveyId, $this->get("promptInput", "Survey", $surveyId), $response);
            $systemPrompt = llmWrapper::createPrompt($surveyId, $this->get("systemPromptInput", "Survey", $surveyId, llmWrapper::$defaultSystemPrompt), $response);
            $model = $this->get("llmodel", "Survey", $surveyId);
            $temperature = $this->get("temperature", "Survey", $surveyId);
            $maxTokens = $this->get("maxTokens", "Survey", $surveyId);
            $topP = $this->get("topP", "Survey", $surveyId);

            $openRouterKey = $this->get("openRouterKey", null, null);
            $llmOutput = llmWrapper::getLLMOutput($openRouterKey, $model, $systemPrompt, $prompt, $temperature, $maxTokens, $topP);
            $this->set("llmoutput", json_encode($llmOutput), "Response_$surveyId", $responseId);
            setcookie("llmOutput_$surveyId", json_encode($llmOutput), 0, "/");
            $this->set("systemPrompt", $systemPrompt, "Response_$surveyId", $responseId);
            $this->set("prompt", $prompt, "Response_$surveyId", $responseId);

            self::saveCurrentSurveyState($surveyId, $responseId);
        } else {
            $llmOutput = json_decode($savedLLMOutput, true);
        }

        // this variable determines which index of the llm output to insert
        $questionNum = -1;

        // get questionNum from question code
        if (preg_match("/^llm(\d+)$/", $event->get("code"), $matches)) {
            $questionNum = $matches[1];
        }
        // if number in question code is bigger than the list from the llm -> out of bounds
        if ($questionNum > count($llmOutput)) {
            dynamicFunctions::hideQuestion($event);
            return;
        }
        if ($questionNum != -1) {
            dynamicFunctions::replaceQuestionText($event, $llmOutput[$questionNum - 1]);
        }
        if ($subquestionIsPlaceholder) {
            dynamicFunctions::replaceSubquestionText($event);
        }
    }

    /**
     * Save LLM-outputs in the corresponding automatically inserted hidden question in the database.
     */
    public function afterSurveyComplete() {
        $event = $this->event;
        $surveyId = $event->get("surveyId");

        // check if plugin is active
        $active = $this->get("bUse", "Survey", $surveyId, false);
        if (!$active) {
            return;
        }

        $responseId = $event->get("responseId");
        self::saveCurrentSurveyState($surveyId, $responseId);

        // delete saved settings for this response from database
        $sql = "DELETE FROM lime_plugin_settings WHERE model = 'Response_$surveyId' AND model_id = $responseId";
        Yii::app()->db->createCommand($sql)->execute();
    }

    /**
     * Adds the LLM-Parameters and the generated LLM-Outputs to the corresponding question fields in the database.
     */
    public function saveCurrentSurveyState($surveyId, $responseId) {
        $survey = Survey::model()->findByPk($surveyId);
        $allQuestions = $survey->getAllQuestions();

        // get saved llm-output
        $llmOutput = $this->get("llmOutput", "Response_$surveyId", $responseId);

        $llmOutputArray = json_decode($llmOutput, true);
        for ($i = 0; $i < count($llmOutputArray); $i++) {
            $qid = null;
            foreach ($allQuestions as $q) {
                $index = $i + 1;
                if ($q->title == "llmOutput$index") {
                    $qid = $q->qid;
                    break;
                }
            }
            if ($qid == null) {
                continue;
            }
            dynamicFunctions::insertAnswerIntoDB($this, $surveyId, $responseId, $qid, $llmOutputArray[$i]);
        }

        $systemPrompt = $this->get("systemPrompt", "Response_$surveyId", $responseId);
        $qid = null;
        foreach ($allQuestions as $q) {
            if ($q->title == "systemPrompt") {
                $qid = $q->qid;
                break;
            }
        }
        if ($qid) {
            dynamicFunctions::insertAnswerIntoDB($this, $surveyId, $responseId, $qid, $systemPrompt);
        }

        $prompt = $this->get("prompt", "Response_$surveyId", $responseId);
        $qid = null;
        foreach ($allQuestions as $q) {
            if ($q->title == "prompt") {
                $qid = $q->qid;
                break;
            }
        }
        if ($qid) {
            dynamicFunctions::insertAnswerIntoDB($this, $surveyId, $responseId, $qid, $prompt);
        }

        $model = $this->get("llmodel", "Survey", $surveyId);
        $qid = null;
        foreach ($allQuestions as $q) {
            if ($q->title == "languageModel") {
                $qid = $q->qid;
                break;
            }
        }
        if ($qid) {
            dynamicFunctions::insertAnswerIntoDB($this, $surveyId, $responseId, $qid, $model);
        }

        $temperature = $this->get("temperature", "Survey", $surveyId);
        $qid = null;
        foreach ($allQuestions as $q) {
            if ($q->title == "llmTemperature") {
                $qid = $q->qid;
                break;
            }
        }
        if ($qid) {
            dynamicFunctions::insertAnswerIntoDB($this, $surveyId, $responseId, $qid, $temperature);
        }

        $maxTokens = $this->get("maxTokens", "Survey", $surveyId);
        $qid = null;
        foreach ($allQuestions as $q) {
            if ($q->title == "llmMaxTokens") {
                $qid = $q->qid;
                break;
            }
        }
        if ($qid) {
            dynamicFunctions::insertAnswerIntoDB($this, $surveyId, $responseId, $qid, $maxTokens);
        }

        $topP = $this->get("topP", "Survey", $surveyId);
        $qid = null;
        foreach ($allQuestions as $q) {
            if ($q->title == "llmTopP") {
                $qid = $q->qid;
                break;
            }
        }
        if ($qid) {
            dynamicFunctions::insertAnswerIntoDB($this, $surveyId, $responseId, $qid, $topP);
        }
    }

    /**
     * Deletes all plugin settings and responses for this survey.
     */
    public function beforeSurveyDelete() {
        $oSurvey = $this->getEvent()->get("model");
        $surveyId = $oSurvey->sid;

        // delete all responses for this survey
        $sql = "DELETE FROM lime_plugin_settings WHERE model = 'Response_$surveyId'";
        Yii::app()->db->createCommand($sql)->execute();
        // delete all settings for this survey
        $sql = "DELETE FROM lime_plugin_settings WHERE model = 'Survey' AND model_id = $surveyId";
        Yii::app()->db->createCommand($sql)->execute();
    }

    /**
     * Delete all stored survey data for this plugin.
     * Keeps the global settings.
     */
    public function beforeDeactivate() {
        $pluginId = $this->id;
        $sql = "DELETE FROM lime_plugin_settings WHERE plugin_id = $pluginId AND model IS NOT NULL";
        Yii::app()->db->createCommand($sql)->execute();
    }
}
