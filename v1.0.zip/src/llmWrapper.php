<?php

require_once "endpoint.php";

class llmWrapper {
    public static $defaultSystemPrompt = 'Answer in the following language [startlanguage].
    
Your answer MUST be in the format:
    [
        "Item1",
        "Item2",
        ...
    ]
Return ONLY the array and no further text.
';

    /**
     * Sends the prompt to the LLM API and returns the response.
     */
    public static function getLLMOutput(string $openRouterKey, string $model, string $systemPrompt, string $prompt, mixed $temperature, mixed $maxTokens, mixed $topP) {
        $payloadArr = [
            "model" => $model,
            "messages" => [["role" => "system", "content" => $systemPrompt], ["role" => "user", "content" => $prompt]]
        ];
        if (isset($temperature) && $temperature != "") {
            $payloadArr["temperature"] = (float) $temperature;
        }
        if (isset($maxTokens) && $maxTokens != "") {
            $payloadArr["max_tokens"] = (int) $maxTokens;
        }
        if (isset($topP) && $topP != "") {
            $payloadArr["top_p"] = (float) $topP;
        }
        $payload = json_encode($payloadArr);

        $ch = curl_init(endpoint::$URL);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
            "Authorization: Bearer " . $openRouterKey
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        //curl_setopt($ch, CURLOPT_TIMEOUT, 60); // Timeout in seconds

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            curl_close($ch);
            return ["ERROR: The api call failed."];
        }
        curl_close($ch);

        $respObj = json_decode($result);
        if ($respObj == null || ($respObj->code !== null && $respObj->code !== 200)) {
            return ["An error occurred while processing the received data: " . $respObj ? $respObj->metadata->raw : "Unknown error"];
        }
        if ($respObj->error) {
            return ["ERROR " . $respObj->error->code . ": " . $respObj->error->message];
        }

        $response = $respObj->choices[0]->message->content;
        return self::parseResponse($response);
    }

    /**
     * Checks if the response is in the correct format.
     * If its not a valid JSON, it tries to find the brackets indicating the list and isolates it.
     * Returns the array containing the LLM objects.
     */
    static function parseResponse($response): array {
        // try to fix if response is like: 'Okay here is your data: ["item1", "item2", ...] Goodbye.'
        if (!is_array($response)) {
            if (str_contains($response, "[") && str_contains($response, "]")) {
                $response = "[" . explode("[", $response)[1];
                $response = explode("]", $response)[0] . "]";
            }
        }
        if ($parsedData = json_decode($response)) {
            return $parsedData;
        } else {
            return ["ERROR: Could not parse received data."];
        }
    }

    /**
     * Reads the prompt and replaces placeholders with actual response data.
     */
    public static function createPrompt(int $surveyId, string $prompt, array $response): string {
        foreach ($response as $key => $value) {
            $placeholder = "[$key]";
            $prompt = str_replace($placeholder, self::parseValue($surveyId, $key, $value), $prompt);
        }
        return $prompt;
    }

    /**
     * Transforms numbers to a string representation and the single characters to human-readable strings.
     */
    static function parseValue(mixed $surveyId, mixed $key, mixed $value) {
        // check if value is an answer code and if so, replace
        $keys = explode("_", $key);
        if (count($keys) == 1 && ($value == null || $value == "")) {
            return "N/A";
        }
        $survey = Survey::model()->findByPk($surveyId);
        $question = null;
        foreach ($survey->allQuestions as $q) {
            if ($q->title == $keys[0]) {
                $question = $q;
                break;
            }
        }
        if (!$question) {
            return $value;
        }
        if (count($keys) > 1 && $question->type != "M" && $question->type != "P" && ($value == null || $value == "")) {
            return "";
        }
        $answer = null;
        foreach ($question->answers as $a) {
            if ($a->code == $value) {
                $answer = $a;
                break;
            }
        }
        if ($answer) {
            $answerStr = null;
            foreach ($answer->answerl10ns as $aLang) {
                if ($aLang->language == "en") {
                    $answerStr = $aLang->answer;
                    break;
                }
                $answerStr = $aLang->answer;
            }
            return $answerStr;
        }

        if ($question->type == "E") { // array inc same dec
            if ($value == "I") {
                return "Increase";
            }
            if ($value == "S") {
                return "Same";
            }
            if ($value == "D") {
                return "Decrease";
            }
            return "Unknown value";
        }
        if ($question->type == "C") { // array yes uncertain no
            if ($value == "Y") {
                return "Yes";
            }
            if ($value == "U") {
                return "Uncertain";
            }
            if ($value == "N") {
                return "No";
            }
            return "Unknown value";
        }
        if ($question->type == "M" || $question->type == "P") { // multiple choice || multiple choice with comment
            if (str_contains($keys[1], "comment")) {
                return $value;
            }
            if ($value == "Y") {
                return "Yes";
            } else {
                return "No";
            }
        }
        if ($question->type == "G") { // gender
            if ($value == "F") {
                return "Female";
            }
            if ($value == "M") {
                return "Male";
            }
            return "N/A";
        }
        if ($question->type == "N" || $question->type == "K") { // numerical || multiple numerical
            return number_format($value);
        }
        if ($question->type == "Y") { // yes no radio
            if ($value == "Y") {
                return "Yes";
            }
            if ($value == "N") {
                return "No";
            }
            return "No answer";
        }
        return $value;
    }
}
