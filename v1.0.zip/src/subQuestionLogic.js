window.addEventListener("DOMContentLoaded", main);

function main() {
  const url = new URL(window.location.href);
  const path = url.pathname;
  const segments = path.split("/"); // ["", "index.php", "{surveyId}?..."]
  const surveyId = segments[2].split("?")[0];

  // looks for the cookie containing the llm output for this survey
  const cookieName = `llmOutput_${surveyId}`;
  const parts = `; ${document.cookie}`.split(`; ${cookieName}=`);
  if (parts.length !== 2) {
    console.error("Could not find llm output for this survey.");
    return;
  }
  let llmOutputStr = parts.pop().split(";").shift();
  if (!llmOutputStr) {
    console.error("Could not retrieve llm output for this survey.");
    return;
  }

  llmOutputStr = decodeURIComponent(llmOutputStr);
  const llmOutput = JSON.parse(llmOutputStr);

  // get all subquestions and replace text
  const subquestions = getAllSubquestions();
  for (const sq of subquestions) {
    if (sq.id.match(/llm\d+$/)) {
      replaceSubquestionText(sq, llmOutput);
    } else if (sq.value && sq.value.match(/^llm\d+$/)) {
      replaceDropdownText(sq, llmOutput);
    }
  }
}

function getAllSubquestions() {
  return document.querySelectorAll(
    ".answers-list, .radio-list, .subquestion-list, .answer-item, .checkbox-text-item, .bootstrap-buttons-div, select > option, .answertext, .answer-text, .answer-item",
  );
}

/**
 * Matches the number of the code to the index of the output array and inserts the output into the subquestion dom element.
 */
function replaceSubquestionText(sq, llmOutput) {
  const outputId = sq.id.match(/llm(\d+)$/)[1];
  if (outputId > llmOutput.length) {
    // hide this subquestion
    sq.style.display = "none";
    return;
  }

  let sqText = sq.querySelector("th.answertext");
  if (!sqText && (sq.nodeName == "TH" || (sq.nodeName == "LI" && sq.classList.contains("sortable-item")))) {
    sqText = sq;
  }
  if (sqText) {
    console.log("Normal subquestion");
    let text = sqText.innerHTML;
    const parts = text.split("<", 2);
    sqText.innerHTML = llmOutput[outputId - 1] + "<" + parts[1];
    return;
  }

  const btnText = sq.querySelector("label");
  if (btnText) {
    console.log("Button subquestion");
    btnText.innerHTML = llmOutput[outputId - 1];
    return;
  }
}

/**
 * Matches the number of the code to the index of the output array and inserts the output into the dropdown dom element.
 */
function replaceDropdownText(sq, llmOutput) {
  const outputId = sq.value.match(/^llm(\d+)$/)[1];
  if (outputId > llmOutput.length) {
    sq.style.display = "none";
    return;
  }
  console.log("Dropdown subquestion");
  sq.innerHTML = llmOutput[outputId - 1];
}
